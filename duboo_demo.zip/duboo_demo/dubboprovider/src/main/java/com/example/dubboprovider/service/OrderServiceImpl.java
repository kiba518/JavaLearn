package com.example.dubboprovider.service;

import com.example.dubbointerface.OrderService;
import org.apache.dubbo.config.annotation.DubboService;
import org.apache.dubbo.config.annotation.Method;
import org.apache.dubbo.rpc.RpcException;
import org.springframework.beans.factory.annotation.Value;

@DubboService(
        timeout = 4000
        ,methods = {@Method(name = "getOrder",timeout = 3000)}
        ,retries = 3
        ,group = "1"
)
public class OrderServiceImpl implements OrderService {

    @Value("${dubbo.protocol.port}")
    private String rpcServerPort;

    @Value("${dubbo.provider.version}")
    private String serviceVersion;

    @Override
    public String getOrder(Long orderId) {
        String result = "get order detail ,orderId="+orderId +",rpcServerPort="+rpcServerPort +",serviceVersion="+serviceVersion;
        System.out.println(result);
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (orderId == 0L) {
            throw new RpcException("请降级");
        }
        return result;
    }
}