package com.example.dubbointerface;

public interface OrderService {
    String getOrder(Long orderId);
}
