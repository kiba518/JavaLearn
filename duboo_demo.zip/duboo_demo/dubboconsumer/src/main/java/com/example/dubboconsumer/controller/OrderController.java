package com.example.dubboconsumer.controller;


import com.example.dubbointerface.OrderService;
import org.apache.dubbo.config.annotation.DubboReference;
import org.apache.dubbo.config.annotation.Method;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.registry.NotifyListener;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/order")
public class OrderController {

    /**
     * stub
     */
    @DubboReference(
            timeout = 2500
            ,methods = {@Method(name = "getOrder",timeout = 2000)}
            ,check = false
            ,retries = 3
            ,cluster = "failsafe "
            //,loadbalance = ""
            ,loadbalance = "roundrobin"
            ,group = "1"
            //,version = "v2.0"
//            ,stub = "com.itheima.api.stub.OrderServiceStub"
//            ,mock = "com.itheima.api.mock.OrderServiceMock"
    )
    private OrderService orderService;

    @GetMapping("/getOrder")
    public String getOrder(Long orderId) {
        System.out.println(orderService);
        return orderService.getOrder(orderId);
    }


    public void onreturn(String result,Long orderId) {
        System.out.println("返回之后的结果="+result+"-"+orderId);
    }



}
