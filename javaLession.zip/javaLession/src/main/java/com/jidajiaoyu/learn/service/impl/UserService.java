package com.jidajiaoyu.learn.service.impl;

import com.jidajiaoyu.learn.dao.UserDAO;
import com.jidajiaoyu.learn.fakedata.FakeData;
import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class UserService implements IUserService {


    @Autowired
    UserDAO userDAO;

    @Override
    public boolean insert(User user) {
        user.setNikename(user.getName());
        if(user.getName().length()>4)
        {
            user.setNikename(user.getName().substring(4));
        }
        int count = userDAO.save(user);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean update(User user) {
        int count = userDAO.Update(user);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        int count = userDAO.delete(id);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<User> findAll(User user) {
        if (null != user && user.getId() > 0) {
            return userDAO.findbyId(user.getId());
        } else {
            return userDAO.findAll();
        }
    }


    //#region 假数据
//    @Override
//    public boolean insert(User user) {
//        FakeData.getUser().add(user);
//        return true;
//    }
//
//    @Override
//    public boolean update(User user) {
//        User userUpdate = FakeData.getUser().stream()
//                .filter(p->p.getId()==user.getId()).findFirst().orElse(null);
//        if(userUpdate !=null){
//            userUpdate.setName(user.getName());
//            return true;
//        }
//        else {
//            return false;
//        }
//    }
//
//    @Override
//    public boolean delete(int id) {
//        User user = FakeData.getUser().stream()
//                .filter(p->p.getId()==id).findFirst().orElse(null);
//        FakeData.getUser().remove(user);
//        return true;
//    }
//
//    @Override
//    public List<User> findAll(User user) {
//        return FakeData.getUser();
//    }
    //endregion
}
