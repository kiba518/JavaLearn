package com.jidajiaoyu.learn.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@RestController
public class helloworld {

    /**
     * http://localhost:8080/helloworld/test1
     *
     * @return
     */
    @GetMapping("/helloworld/test1")
    public String Test1() {
        return "user";
    }

    @GetMapping("/helloworld/test2")
    public Integer Test2() {
        return 1;
    }

    /**
     * http://localhost:8518/api/helloworld/test3?a=1
     *
     * @param a
     * @return
     */
    @GetMapping("/helloworld/test3")
    public Integer Test3(int a) {
        return 1;
    }

    @GetMapping("/helloworld/Verify")
    public String Verify() {
        Random random = new Random();
        String code1 = String.valueOf(random.nextInt(10));
        String code2 = String.valueOf(random.nextInt(10));
        String code3 = String.valueOf(random.nextInt(10));
        String code4 = String.valueOf(random.nextInt(10));
        return code1 + code2 + code3 + code4;
    }

    /**
     * http://localhost:8518/api/helloworld/Login?userName=张三&password=123
     * @param userName
     * @param password
     * @return
     */
    @GetMapping("/helloworld/Login")
    public boolean Login(String userName, String password) {
        if(userName.equals("张三")&& password.equals("123")) {
            return true;
        }
        else {
            return false;
        }
    }


    /**
     * http://localhost:8518/api/helloworld/RequestTest1
     *
     * @return
     */
    @RequestMapping(value = "/helloworld/RequestTest1",method = RequestMethod.GET)
    public String RequestTest1() {
        return "RequestTest1";
    }
}
