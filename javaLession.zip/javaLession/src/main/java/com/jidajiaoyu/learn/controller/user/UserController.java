package com.jidajiaoyu.learn.controller.user;

import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/User")
public class UserController {

    @Autowired
    IUserService iUserService;

    @PostMapping("/RegisterUser")
    public boolean Register(@RequestBody User user) {
        boolean ret =false;
        ret = iUserService.insert(user);
        return ret;
    }

    @PostMapping("/DeleteUser")
    public boolean DeleteUser(@RequestParam(value = "id",required = true)
                                          int id) {
        boolean ret =false;
        ret = iUserService.delete(id);
        return ret;
    }
    @PostMapping("/UpdateUser")
    public boolean UpdateUser(@RequestBody User user) {
        boolean ret =false;
        ret = iUserService.update(user);
        return ret;
    }
    @PostMapping("/FindAllUser")
    public List<User> FindAllUser(int id) {
        User user = new User();
        user.setId(id);
        return iUserService.findAll(user);
    }
}
