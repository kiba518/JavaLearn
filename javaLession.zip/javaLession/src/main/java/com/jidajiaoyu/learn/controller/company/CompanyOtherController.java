package com.jidajiaoyu.learn.controller.company;

import com.jidajiaoyu.learn.model.Company;
import com.jidajiaoyu.learn.service.ICompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/CompanyOther")
public class CompanyOtherController {
    @Qualifier("companyServiceImpl")
    @Autowired
    ICompanyService companyService;

    @Autowired
    public ICompanyService companyServiceImpl;
    @Autowired
    public ICompanyService company22222ServiceImpl;

    @PostMapping("/getAll")
    public Boolean getAll(){
        companyService.getAll();
        return false;
    }
}
