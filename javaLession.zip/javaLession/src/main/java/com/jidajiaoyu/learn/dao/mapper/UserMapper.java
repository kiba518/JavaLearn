package com.jidajiaoyu.learn.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.model.UserExtend;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;
import sun.plugin2.main.server.ResultHandler;

import java.util.List;
import java.util.Map;


@Repository
public interface UserMapper extends BaseMapper<User> {

    @Select("select * from k_user")
    List<User> getAll_Custom();

    @Select("select * from k_user where id=#{id}")
    List<User> getUserById(int id);

    @Select("select * from k_user where name=#{value}")
    List<User> getUserById2(String name);

    @Select("select * from k_user where id=#{id} and name =#{name}")
    List<User> getUserById3(int id,String name);

    @Select("select * from k_user where name like concat('%',#{name},'%')")
    List<User> getUserById4(String name);

    @Select("select * from k_user where like #{name} order by id desc")
    List<User> getUserById5(String name);

    List<User> getUserById6(String name);

    /**
     *  sql ="  '赵四' order by id desc  "
     */
    @Select("select * from k_user where name=${value}")
    List<User> getUserById7(String sql);

    List<User> getUserById8(String sql);

    List<User> getUserById9(String name);

    List<User> getUserById10(@Param("id") String userId);

    List<User> getUserById11(@Param("id") String userId,@Param("name") String userName);

    List<User> getUserById12(@Param("user") User user);

    List<User> getUserById13(@Param("name") String name);

    int insertUser18(Map<String,Object> map);

    List<UserExtend> getUserMap();

}
