package com.jidajiaoyu.learn.controller.user;


import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.model.UserExtend;
import com.jidajiaoyu.learn.service.IUserMapperService;
import com.jidajiaoyu.learn.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/UserMapper")
public class UserMapperController {

    @Autowired
    IUserMapperService iUserMapperService;

    @PostMapping("/FindAllUser")
    public List<User> FindAllUser(int id) {
        User user = new User();
        user.setId(id);
        return iUserMapperService.findAll(user);
    }


    @PostMapping("/getUserById")
    public  List<User>  getUserById(int id) {
        return iUserMapperService.getUserById(id);
    }

    @PostMapping("/getUserById2")
    public  List<User>  getUserById2(String name) {
        return iUserMapperService.getUserById2(name);
    }

    @PostMapping("/getUserById3")
    public  List<User>  getUserById3(int id,String name) {
        return iUserMapperService.getUserById3(id,name);
    }
    @PostMapping("/getUserById4")
    public  List<User>  getUserById4(String name) {
        return iUserMapperService.getUserById4(name);
    }
    @PostMapping("/getUserById6")
    public  List<User>  getUserById6(String name) {
        return iUserMapperService.getUserById6(name);

    }

    /**
     * @param name '赵四' order by id desc
     */
    @PostMapping("/getUserById7")
    public  List<User>  getUserById7(String name) {
        return iUserMapperService.getUserById7(name);
    }

    /**
     * @param name '赵四' order by id desc
     */
    @PostMapping("/getUserById8")
    public  List<User>  getUserById8(String name) {
        return iUserMapperService.getUserById8(name);
    }
    @PostMapping("/getUserById9")
    public  List<User>  getUserById9(String name) {
        return iUserMapperService.getUserById9(name);
    }
    @PostMapping("/getUserById12")
    public  List<User>  getUserById12(@RequestBody User user) {
        return iUserMapperService.getUserById12(user);
    }

    @PostMapping("/getUserById14")
    public  List<User>  getUserById14(int id) {
        return iUserMapperService.getUserById14(id);
    }

    @PostMapping("/getUserById18")
    public  List<User>  getUserById18() {
        return iUserMapperService.insertUser18();
    }
    @PostMapping("/getUserById19")
    public List<User> getUserById19() {
        Map<String,Object> map = new HashMap<>();
        map.put("name","王二");
        map.put("nikename","萧峰");
        map.put("phone",159);
        return iUserMapperService.getUserById19(map);
    }
    @PostMapping("/getUserMap")
    public List<UserExtend> getUserMap() {
        return iUserMapperService.getUserMap();
    }

    @PostMapping("/getUserById20")
    public List<User> getUserById20() {
        return iUserMapperService.getUserById20();
    }

    @PostMapping("/getUserById21")
    public List<User> getUserById21() {
        return iUserMapperService.getUserById21();
    }
    @PostMapping("/getUserById100")
    public List<User> getUserById100() {
        return iUserMapperService.getUserById100();
    }



}
