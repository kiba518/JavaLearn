package com.jidajiaoyu.learn.dao;

import com.jidajiaoyu.learn.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.Resource;
import java.util.List;

@Repository
public class UserDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int save(User user) {
        return jdbcTemplate.update("insert into k_user " +
                        "(name,sex,phone,idcardCode,birthday) " +
                        "values (?,?,?,?,?)",
                user.getName(),user.isSex(),user.getPhone(),
                user.getIdcardcode(),user.getBirthday());
    }

    public int Update(User user) {
        return jdbcTemplate.update("update k_user " +
                        "set name=? where id =?",
                user.getName(),user.getId());
    }

    public int delete(int id) {
        String deletesql = "delete from k_user where id=?";
        return jdbcTemplate.update(deletesql, id);
    }

    public List<User> findAll() {
        return jdbcTemplate.query("select * from k_user",
                BeanPropertyRowMapper.newInstance(User.class));

    }
    public List<User> findbyId(int id) {
        return jdbcTemplate.query("select * from k_user where id=?",
                BeanPropertyRowMapper.newInstance(User.class),id);
    }
}
