package com.jidajiaoyu.learn.model;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.Date;

@TableName("k_company")
@Data
public class Company {
    private int id;
    @NotEmpty(message = "姓名不可为空")
    private String name;
}
