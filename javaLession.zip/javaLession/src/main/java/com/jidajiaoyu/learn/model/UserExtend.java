package com.jidajiaoyu.learn.model;

import lombok.Data;

@Data
public class UserExtend {
    private int u_id;
    private String u_name;
}
