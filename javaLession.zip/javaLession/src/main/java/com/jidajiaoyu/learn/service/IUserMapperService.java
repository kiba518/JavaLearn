package com.jidajiaoyu.learn.service;

import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.model.UserExtend;

import java.util.List;
import java.util.Map;

public interface IUserMapperService {

    boolean insert(User user);

    boolean update(User user);

    boolean delete(int id);

    List<User> findAll(User user);

    List<User> getAll_Custom();

    List<User> getUserById(int id);

    List<User> getUserById2(String name);

    List<User> getUserById3(int id,String name);

    List<User> getUserById4(String name);

    List<User> getUserById5(String name);

    List<User> getUserById6(String name);

    List<User> getUserById7(String name);

    List<User> getUserById8(String name);

    List<User> getUserById9(String name);

    List<User> getUserById10(String name);

    List<User> getUserById11(String name);

    List<User> getUserById12(User user);

    List<User> getUserById13(String name);

    List<User> getUserById14(int id);

    List<User> getUserById15(int id);

    List<User> getUserById16(int id);

    List<User> getUserById17(int idmin,int idmax);

    List<User> insertUser18();

    List<User> getUserById19(Map map);

    List<User> getUserById20();

    List<User> getUserById21();

    List<User> getUserById100();



    List<UserExtend> getUserMap();
}
