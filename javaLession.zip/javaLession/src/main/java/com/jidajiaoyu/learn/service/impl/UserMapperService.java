package com.jidajiaoyu.learn.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jidajiaoyu.learn.dao.UserDAO;
import com.jidajiaoyu.learn.dao.mapper.UserMapper;
import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.model.UserExtend;
import com.jidajiaoyu.learn.service.IUserMapperService;
import com.jidajiaoyu.learn.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserMapperService implements IUserMapperService {


    @Autowired
    UserMapper userMapper;

    @Override
    public boolean insert(User user) {
        user.setNikename(user.getName());
        if(user.getName().length()>4)
        {
            user.setNikename(user.getName().substring(4));
        }
        int count = userMapper.insert(user);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * updateById是根据user的id进行更新数据，要求user参数的id不能为null
     * @param user
     * @return
     */
    @Override
    public boolean update(User user) {
        int count = userMapper.updateById(user);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public boolean delete(int id) {
        int count = userMapper.deleteById(id);
        if (count > 0) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<User> findAll(User user) {
        List<User> list =new ArrayList<>();
        if (null != user && user.getId() > 0) {
            User user1 = userMapper.selectById(user.getId());
            list.add(user1);
            return list;
        } else {
            return userMapper.selectList(null);
        }
    }
    @Override
    public List<User> getAll_Custom() {
        List<User> list =new ArrayList<>();
        return userMapper.getAll_Custom();
    }

    @Override
    public List<User> getUserById(int id) {

        return userMapper.getUserById(id);
    }

    @Override
    public List<User> getUserById2(String name) {
        return userMapper.getUserById2(name);
    }

    @Override
    public List<User> getUserById3(int id,String name) {
        return userMapper.getUserById3(id,name);
    }

    @Override
    public List<User> getUserById4(String name) {
        return userMapper.getUserById4(name);
    }

    @Override
    public List<User> getUserById5(String name) {
        return null;
    }

    @Override
    public List<User> getUserById6(String name) {
        return userMapper.getUserById6(name);
    }
    @Override
    public List<User> getUserById7(String sql) {
        return userMapper.getUserById7(sql);
    }

    @Override
    public List<User> getUserById8(String sql) {
        return userMapper.getUserById8(sql);
    }

    @Override
    public List<User> getUserById9(String sql) {
        return userMapper.getUserById9(sql);
    }

    @Override
    public List<User> getUserById10(String name) {
        return null;
    }

    @Override
    public List<User> getUserById11(String name) {
        return null;
    }

    @Override
    public List<User> getUserById12(User user) {
        return userMapper.getUserById12(user);
    }

    @Override
    public List<User> getUserById13(String name) {
        return userMapper.getUserById13(name);
    }


    @Override
    public List<User> getUserById14(int id) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("id", id);//id = #{id}
        wrapper.ne("id", id);//不等于
        List<User> list = userMapper.selectList(wrapper);
        return list;
    }

    @Override
    public List<User> getUserById15(int id) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.le("id", id);//小于等于
        wrapper.lt("id", id);//小于
        List<User> list = userMapper.selectList(wrapper);
        return list;
    }

    @Override
    public List<User> getUserById16(int id) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.ge("id", id);//大于等于
        wrapper.gt("id", id);//大于
        List<User> list = userMapper.selectList(wrapper);
        return list;
    }



    @Override
    public List<User> getUserById17(int idmin,int idmax) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.between("id", idmin,idmax);//between
        List<User> list = userMapper.selectList(wrapper);
        return list;
    }


    @Override
    public List<User> insertUser18() {
        Map<String,Object> map=new HashMap<>();
        if(map.containsKey("name"))
        {
        }
        map.put("name","王二");
        map.put("nikename","萧峰");
        map.put("phone",159);
        int i = userMapper.insertUser18(map);
        return null;
    }


    @Override
    public List<User> getUserById19(Map map) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.allEq(map);//between
        List<User> list = userMapper.selectList(wrapper);
        return list;
    }


    @Override
    public List<User> getUserById20() {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.like("name","张");//模糊查询 %张%
        wrapper.like("name","王");//模糊查询 %张%
        // name like '%张%'  and name like '%王%'
        wrapper.or(w->w.like("name","王"));//模糊查询 %张%
        // name like '%张%' or name like '%王%'


        wrapper.like("name","张");//模糊查询 %张%
        wrapper.like("name","王");//模糊查询 %张%

        wrapper.like("name","张")
                .like("name","王");

        List<User> list = userMapper.selectList(wrapper);
        return list;
    }

    @Override
    public List<User> getUserById21() {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.and(p->p.like("name","王"));
        wrapper.or(p->p.like("name","张"));
        List<User> list = userMapper.selectList(wrapper);
        return list;
    }



    @Override
    public List<UserExtend> getUserMap() {
        List<UserExtend> list = userMapper.getUserMap();
        return list;
    }


    @Override
    public List<User> getUserById100() {
        Page<User> page = new Page<>(1, 2);
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("id", 1);
        IPage<User> orderPage = userMapper.selectPage(page,
                null);
        List<User> orders = orderPage.getRecords();
        long total = orderPage.getTotal();
        return orders;
    }

}
