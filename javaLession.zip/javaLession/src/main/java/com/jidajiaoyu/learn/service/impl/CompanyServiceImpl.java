package com.jidajiaoyu.learn.service.impl;

import com.jidajiaoyu.learn.model.Company;
import com.jidajiaoyu.learn.service.ICompanyService;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CompanyServiceImpl implements ICompanyService {
    @Override
    public List<Company> getAll() {
        return null;
    }
}
