package com.jidajiaoyu.learn.controller;

import com.jidajiaoyu.learn.model.User;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/helloworld5")
public class helloworld5 {

    @PostMapping("/Register")
    public boolean Register(@RequestBody User user) {
        int id = user.getId();
        return true;
    }


    @PostMapping("/test1")
    public HttpEntity test1(@RequestBody User user) {
        if (user.getId() > 0) {
            user.setName("张三");
            return new ResponseEntity(user, HttpStatus.OK);
        } else {
            List<User> list = new ArrayList<>();
            list.add(user);
            list.add(user);
            return new ResponseEntity(list, HttpStatus.OK);
        }
    }

    @PostMapping("/test2")
    public String test2(@Validated @RequestBody User user) {
        System.out.println(user);
        return "hello success";
    }

    @PostMapping("/test3")
    public String test3(@Validated @RequestBody User user, BindingResult results) {
        System.out.println(user);
        if (results.hasErrors()) {
            FieldError FieldError = results.getFieldError();
            return FieldError.getDefaultMessage();
        } else {
            return "hello success";
        }
    }
}
