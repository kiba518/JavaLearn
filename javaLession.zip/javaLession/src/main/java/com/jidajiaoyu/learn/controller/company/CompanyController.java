package com.jidajiaoyu.learn.controller.company;

import com.jidajiaoyu.learn.model.Company;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequestMapping("/Company")
public class CompanyController {



    private static List<Company> companyList;
    private static List<Company> getCompany(){
        if(companyList==null)
        {
            companyList=new ArrayList<Company>();
        }
        return companyList;
    }

    @PostMapping("/insert")
    public Boolean insert(@RequestBody Company company){
        getCompany().add(company);
        return false;
    }
    @PostMapping("/query")
    public List<Company> query(@RequestBody Company company){
       return getCompany();
    }
    @GetMapping("/query2")
    public List<Company> query2(int companyid1,int companyid2){
        List<Company> list =getCompany();
        List<Company> listRet =new ArrayList<>();
        for(int i =0 ;i<list.size(); i++){
           if(companyid1 == list.get(i).getId() || companyid2 ==list.get(i).getId())
           {
               listRet.add(list.get(i));
           }
        }
        return listRet;

//       return getCompany().stream().filter(p->p.getId()==companyid1 || p.getId() ==companyid2)
//                .collect(Collectors.toList());
    }


    @GetMapping("/query3")
    public Company query3(String name)
    {
        List<Company> list =getCompany();
        Company company=null;
        for(int i =0 ;i<list.size(); i++){
            if(list.get(i).getName().contains("吉大"))
            {
                company= list.get(i);
            }
        }
        return company;
    }


    @GetMapping("/query4")
    public List<Company> query4(int companyid1,int companyid2){

       return getCompany().stream().
               filter(p->p.getId()==companyid1 || p.getId() ==companyid2)
                .collect(Collectors.toList());
    }

    @GetMapping("/query5")
    public Company query5(String name)
    {
        return getCompany().stream().
                filter(p->p.getName().contains(name)).findFirst().get();

    }
}
