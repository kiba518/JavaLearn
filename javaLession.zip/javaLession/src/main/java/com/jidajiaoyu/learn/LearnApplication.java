package com.jidajiaoyu.learn;

import lombok.extern.log4j.Log4j2;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import sun.rmi.runtime.Log;

@EnableSwagger2
@Log4j2
@MapperScan("com.jidajiaoyu.learn.dao.mapper")
@SpringBootApplication
public class LearnApplication {

    public static void main(String[] args) {

        ConfigurableApplicationContext application = SpringApplication.run(LearnApplication.class, args);
        Environment env = application.getEnvironment();

        System.out.println("项目启动");
        log.info("--------------------------------------------------------------------------------------------------------------------");
        log.info("-----------------启动模块:{}", env.getProperty("server.servlet.context-path"));
        log.info("-----------------启动端口:{}", env.getProperty("server.port"));
        log.info("-----------------api地址:{}", "http://localhost:" +
                env.getProperty("server.port") + env.getProperty("server.servlet.context-path"));
        log.info("-----------------swagger-ui:{}",
                "http://localhost:" + env.getProperty("server.port")+
                        env.getProperty("server.servlet.context-path")+"/swagger-ui.html");
    }

}
