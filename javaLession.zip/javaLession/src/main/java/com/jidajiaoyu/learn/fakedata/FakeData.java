package com.jidajiaoyu.learn.fakedata;

import com.jidajiaoyu.learn.model.Company;
import com.jidajiaoyu.learn.model.User;

import java.util.ArrayList;
import java.util.List;

public class FakeData {

    private static List<Company> companyList;
    public static List<Company> getCompany(){
        if(companyList==null)
        {
            companyList=new ArrayList<Company>();
        }
        return companyList;
    }

    private static List<User> UserList;
    public static List<User> getUser(){
        if(UserList==null)
        {
            UserList=new ArrayList<User>();
        }
        return UserList;
    }
}
