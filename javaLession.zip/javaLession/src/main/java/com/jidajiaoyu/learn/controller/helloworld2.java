package com.jidajiaoyu.learn.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/helloworld2")
public class helloworld2 {

    /**
     * http://localhost:8518/api/helloworld2/test1
     *
     * @return
     */
    @GetMapping("/test1")
    public String Test1() {
        return "user";
    }
    @GetMapping("/test2")
    public Integer Test2() {
        return 1;
    }
}
