package com.jidajiaoyu.learn.service;

import com.jidajiaoyu.learn.model.Company;

import java.util.List;

public interface ICompanyService {
    List<Company> getAll();
}
