package com.jidajiaoyu.learn.model;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.util.Date;

@TableName("k_user")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @TableId
    private int id;
    @NotEmpty(message = "姓名不可为空")
    private String name;
    @TableField("nikename")
    private String nikename;
    private boolean sex;
    private String phone;
    private String idcardcode;
    private Date birthday;
    private int companyid;
}
