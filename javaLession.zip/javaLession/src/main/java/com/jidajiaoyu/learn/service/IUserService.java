package com.jidajiaoyu.learn.service;

import com.jidajiaoyu.learn.model.User;
import com.jidajiaoyu.learn.model.UserExtend;

import java.util.List;

public interface IUserService {

    boolean insert(User user);

    boolean update(User user);

    boolean delete(int id);

    List<User> findAll(User user);


}
